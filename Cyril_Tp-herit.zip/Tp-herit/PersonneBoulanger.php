<?php
     class PersonneBoulanger extends Personne{
        public function dormir() {
            return "le(la) boulanger(ère) dort à 22h" ;
        }
    }
?>