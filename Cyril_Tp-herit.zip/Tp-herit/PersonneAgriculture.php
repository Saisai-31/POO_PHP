<?php
    class PersonneAgriculture extends Personne{
        public function dormir() {
            return "l'agriculteur(trice) dort à 19h" ;
        }
    }

?>