<?php
     class PersonneInfirmier extends Personne{
        public function dormir() {
            return "l'infirmier(ère) ne dort presque pas" ;
        }
     }

?>